function call(day) { //called when click event on callendar date

}

function colorise(day_state) { // called when callendar is builded change colors of cell depending of free or your_second shift or others second shift
    // day_states
    // 0 - free
    // 1 - some one else is second shift
    // 2 - my day for second shift
}