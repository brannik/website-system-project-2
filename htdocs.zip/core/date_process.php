<?php
require("includes.php");
require(ROOT . "session.php");
include(CONFIG . "config.php");

?>